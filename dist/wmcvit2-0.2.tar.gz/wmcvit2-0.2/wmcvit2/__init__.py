from wmcvit2.a import only
