class only:
 a = "your code goes here 2 "
if __name__ == "__main__":
 p1 = only()
 print(p1.a)
